package com.mmall.dao;

public interface TestDao {
}
